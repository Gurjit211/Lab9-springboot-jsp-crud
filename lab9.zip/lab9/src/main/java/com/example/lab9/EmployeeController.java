package com.example.lab9;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class EmployeeController {

    private List<Employee> employeeList = new ArrayList<>();

    @GetMapping("/")
    public String viewEmployees(Model model) {
        model.addAttribute("employees", employeeList);
        return "employeeList"; // maps to employeeList.jsp
    }

    @GetMapping("/addEmployee")
    public String showAddForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "addEmployee"; // maps to addEmployee.jsp
    }

    @PostMapping("/addEmployee")
    public String addEmployee(@ModelAttribute("employee") Employee emp) {
        emp.setId(employeeList.size() + 1); // Simple ID generation
        employeeList.add(emp);
        return "redirect:/";
    }

    @GetMapping("/searchEmployee")
    public String searchEmployee(@RequestParam("keyword") String keyword, Model model) {
        List<Employee> filtered = new ArrayList<>();
        for (Employee emp : employeeList) {
            if (emp.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                    emp.getDepartment().toLowerCase().contains(keyword.toLowerCase())) {
                filtered.add(emp);
            }
        }
        model.addAttribute("employees", filtered);
        return "employeeList";
    }

    @GetMapping("/updateEmployee/{id}")
    public String showUpdateForm(@PathVariable int id, Model model) {
        Employee emp = employeeList.get(id - 1);
        model.addAttribute("employee", emp);
        return "updateEmployee";
    }

    @PostMapping("/updateEmployee")
    public String updateEmployee(@ModelAttribute("employee") Employee emp) {
        employeeList.set(emp.getId() - 1, emp);
        return "redirect:/";
    }

    @GetMapping("/deleteEmployee/{id}")
    public String deleteEmployee(@PathVariable int id) {
        employeeList.removeIf(e -> e.getId() == id);
        return "redirect:/";
    }
}
